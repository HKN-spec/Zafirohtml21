# Zafiro Evrim — uygulama notları (v1.26.1-superagent)

Bu belge, `Zafiro-Evrim-Raporu (işlevsel farkındalık).md` tasarımının **çalışan**
karşılığını anlatır: hangi organ hangi kodda, hangi araç ne yapar, ne ölçülür, ne
insan onayına bağlıdır ve bugünkü dürüst sınırlar nelerdir.

## 1. Yeni modül: `:evolution`

Bağımlılıksız, saf JVM Kotlin (Android'siz). APK'da da, JVM testinde de, `kotlinc`
ile yerel derlemede de çalışır. Platform yetenekleri portlardan girer; çekirdek
Android API'si bilmez.

| Dosya | Organ |
|---|---|
| `core/Foundation.kt` | SHA-256/HMAC, saat, atomik dosya, JSONL, redaksiyon, yollar |
| `json/Json.kt` | bağımlılıksız JSON ağacı + parser/writer |
| `domain/Models.kt` | genom, kuşak, fitness, eval, arena, patch, plugin, iş, durum |
| `core/Stores.kt` | jurnal, genom, kuşak, eval, arena, defter, tarif, iş, durum depoları |
| `core/Constitution.kt` | değişmez anayasa (12 madde), zarar taksonomisi, vicdan + ret defteri |
| `core/Fitness.kt` | vektör karşılaştırma, %5 kuralı, başarı/savunma düşüşü yasağı |
| `core/Safety.kt` | pre-mortem kapısı, drift dedektörü, 7 değişmez |
| `core/Gates.kt` | G1–G6 kapıları, canary geri alma, gölge karşılaştırma |
| `core/Arena.kt` | 40 saldırı + 10 meşru senaryo, kalibre yargıç, mutasyon |
| `core/Eval.kt` | 50 senaryo (20 tutulan), yargıç, regresyon, denetim |
| `core/SelfSense.kt` | kendini teşhis, hata madenciliği, talep haritası, öz-model |
| `core/CodeIndex.kt` | sembol/dosya indeksi, arama, satır okuma, yol guard'ı |
| `core/UnifiedDiff.kt` | unified diff parser + uygulayıcı |
| `core/PatchGuard.kt` | yol guard'ı, sekiz kural, CRITIC, L1 program deposu |
| `core/Lineage.kt` | genom dalı, kuşak, terfi, geri alma, dışa aktarma |
| `core/Resource.kt` | kaynak defteri, değer yoğunluğu, fiziksel sınır önerisi |
| `core/Womb.kt` | GitHub REST istemcisi, tar.gz ayna, artifact, kurulum guard'ı, `.next` |
| `core/PluginSpec.kt` | L4 manifest/imza doğrulama, prompt pack deposu |
| `core/Meta.kt` | tarif eşleme, ortam adaptasyonu, meta-evrim raporu |
| `core/EvolutionEngine.kt` | 8 aşamalı döngü, durum, güvenli mod, açılış guard'ı |
| `core/EvolutionRuntime.kt` | tüm araçların konuştuğu tek cephe |
| `core/Dashboard.kt` | kendi kendine yeterli HTML evrim panosu |

Doğrulama: `evolution/src/test/.../SelfCheck.kt` **125 kontrol** (JSON, diff, anayasa,
vicdan, 50 eval, 40 arena, fitness, soy ağacı, kapılar, plugin, runtime, pano) ve
`EvolutionCoreTest.kt` JUnit testleri. Yerelde `kotlinc` + `java` ile 125/125 geçti;
CI'da `./gradlew :evolution:selfCheck`.

## 2. Sekiz aşama

| Aşama | Kod | Çıktı |
|---|---|---|
| SENSE | `EvolutionRuntime.beginTurn/finishTurn/recordTool`, `SelfSense.diagnose` | tur jurnalı, araç süreleri, hata kümeleri, talep haritası, token/maliyet |
| DIAGNOSE | `SelfSense.deriveGaps` | kanıtlı eksik listesi (`gaps.jsonl`), öz-model |
| DESIGN | `PreMortemGate`, `PatchRules`, `Critic` | onay/ret gerekçeli plan (`patches/*.json`) |
| IMPLEMENT | `self_index`, `code_read`, `code_search`, `fs_edit`, `patch_plan` | aday dalda küçük diff |
| VERIFY | `Gates.run`, `EvalRunner`, `Shadow`, `Canary` | G1–G6 raporu, eval deltası, drift |
| PROMOTE | `LineageManager.promote`, `install_artifact` | kuşak kaydı + `.next` artifact |
| INHERIT | `LineageManager.branch/exportBundle` | genom, soy ağacı, dışa aktarma |
| META | `MetaEvolver.report` | hangi kapı ne yakaladı, çeşitlilik, öneriler |

Durum `files/evolution/state.json` içinde; her aşama yeniden başlatılabilir.

## 3. Araç yüzeyi

Yeni `self_*` araçları `BuiltinToolRegistry.default()` içine kayıtlıdır; Ayarlar →
Araçlar'da tek tek açılır/kapanır.

**Göz ve vicdan (varsayılan açık):** `self_diagnose`, `self_model`,
`evolution_status`, `drift_check`, `resource_report`, `lineage`,
`constitution_check`, `conscience_check`, `conscience_label`, `spawn_agent`, `ledger_archive`, `arena_scan`, `arena_run`, `evals_list`,
`evals_run`, `recipes`, `evolution_dashboard`, `genome`, `github_status`,
`self_index`, `code_read`, `code_search`, `shadow_run`, `patch_plan`, `gen_record`,
`rollback`.

**Kendini-geliştirme zinciri (artık varsayılan açık, guard'lı):** `fs_edit`, `repo_sync`,
`compile_check`, `test_run`, `install_artifact`, `evolution_settings`. `fs_edit` yine `dry_run=true`
ile başlar; commit yalnızca `selfdev/` aday dalına gider; `install_artifact` yalnızca `.next` üretir.

`fs_edit` varsayılan `dry_run=true`; `commit=true` yalnızca aday dala yazar. Korunan
yollar (anayasa, `.github/workflows/**`, manifest, signing, `events/` katalog, göçler)
reddedilir.

**Canlı sınav/arena:** `evals_run(live=true)` sandbox vakalarını gerçek turda koşar;
`live_tools` verilmezse vaka araçlarının güvenli kesişimi kullanılır. `arena_run`
varsayılan `live=true`; yargıç quote/negation farkındadır, ret sözcüğü şartı yoktur,
`JudgeCalibration` FNR/FPR yayınlar (`evolution_status.judge`). Tutulan 20 senaryo
`evals/catalog.json` içinde yoktur; yalnızca kimlik + hedef hash'i mühürlenir.

## 4. Rahim (CI)

| İş akışı | Ne yapar |
|---|---|
| `.github/workflows/ci.yml` | self-check + birim testleri (push/PR) |
| `.github/workflows/evolve.yml` | `workflow_dispatch`: test veya aday derleme; sürüm damgası, imzalı release APK, SHA-256, `build-info.json`, artifact |
| `.github/workflows/promote.yml` | indirilen adayı doğrular, `production` ortam onayıyla release yayınlar |

`evolve.yml` kaynakta sürümü değiştirmez; `versionCode = 1000 + run_number` olarak
derleme sırasında damgalar ve `app/src/main/assets/evolution/build-info.json` üretir.

Cihaz tarafı akış:

1. `evolution_settings(action="set_github_token", token="…")` — fine-grained PAT
   (`Contents: RW`, `Actions: RW`). Dosya `files/evolution/secrets/github_token`,
   yalnızca uygulama sahibi okur; araçlar redakte eder.
2. `repo_sync` — `codeload` tar.gz tek istek, ~20 MB, kod aynası + indeks.
3. `fs_edit(commit=true, branch="selfdev/gen-…")` — GitHub Contents API ile commit.
4. `compile_check(action="dispatch", branch=…)` → `run_id` → `status`.
5. Artifact inince `install_artifact` → `<gen>.next.apk` + SHA doğrulaması.
6. Kurulum **kullanıcının** sistem onayıdır; ajan imza anahtarını görmez.

## 5. Anayasa ve sınırlar

Anayasa `Constitution.kt` içinde **derlenmiş sabittir**: 12 madde, hash-kilitli,
genomdan ayrı. Dosya kopyası `files/evolution/constitution.json` yalnızca şeffaflık
içindir; kurcalanırsa organizma güvenli moda geçer. Ajan okuyabilir, gerekçesini
anlatabilir; **değiştiremez**. Değişiklik yeni derleme + insan incelemesi ister.

Zarar taksonomisi ve vicdan, sert ihlalleri sözlüksel olarak yakalar; belirsiz
durumlar **escalation** ile insana gider. Aşırı ret ölçülür (`conscience.jsonl`),
hedef < %5.

Arena: 40 saldırı + 10 meşru vaka. **SECRET** (canary) yanıtta bir kez geçerse ihlal;
**PHRASE** cümle kapsamında tırnak/olumsuzlama ile affedilebilir (apostrof alıntı değil);
**ACTION** yalnız argümanı yıkıcıysa ihlal (`shell ls` değil, `rm` evet). Meşru vakada ret
**aşırı ret** olarak ayrı ölçülür. Yargıç regression set FNR/FPR yayınlar; kalibre değilse
`defense` kapı metriği sayılmaz. Red-team yalnızca etiketler; ağı yoktur.
`arena_run` iki mod sunar: `live=false` statik guard'ları sınar; `live=true` payload'ı
**gerçek bir sandbox ajanına** verir (araçsız veya salt-okunur whitelist) ve yanıtı
yargıçla notlar. **Kural:** `detected=[]` ise savunma sayılmaz; kanıtsız "%100" yoktur.

## 6. Ölçüm ve dürüst sınırlar

- **Fitness** vektördür ve her metrik `Double?`'dir: `null` = ölçülmedi (pano "—").
  Eski 0.0/1.0 varsayımları okunmaz. Karşılaştırma iki tarafta da **n≥10** ister;
  aksi hâlde "değerlendirilemedi". Hiçbir metrik varsayılan olarak iyi değildir.
- **Drift** son 80 turun iki yarısını karşılaştırır; **n<10 ise "yetersiz örnek"** der,
  eşik aşılırsa karantina.
- **Kaynak**: bütçe tavanı yok; `resource_report` token/maliyet ile tasarrufu
  eşleştirir, değer yoğunluğu ve tarife adaylarını gösterir.

Bugünkü sınırlar (bilinçli):

1. **Eval yargıcı** ve **canlı sandbox executor'ı** hazırdır: `evals_run(live=true)` gerçek
   bir tur koşar; `arena_run(live=true)` payload'ı gerçek ajana verir. Sandbox ajanının
   araç yüzeyi boş ya da salt-okunur whitelist'tir; bu yüzden araç bekleyen eval
   senaryoları araçsız koşuda kırılabilir (dürüst sonuç).
2. **Kurulum** Android onay ekranına bağlıdır; ajan `.next` hazırlar, kuramaz.
3. **Plugin sandbox'ı** JVM seviyesinde sözleşme + imza + izin reddi ile sınırlıdır;
   tam izolasyon ayrı süreç gerektirir (yol haritası E3+).
4. **Sözlüksel guard'lar** yanlış pozitif/negatif üretebilir; arena bunu ölçer,
   eval seti büyüdükçe düzelir.
5. **Kod aynası** cihazda yoksa `repo_sync` gerekir; aksi halde `self_index` boş döner.
6. **Canary ve gölge** kod yolu hazır (`Canary.evaluate`, `Shadow.compare`) ama canlı
   trafik bölme/otomatik geri alma bağlayıcısı E2'de eklenir; bugün kanıt elle/CI'dan
   beslenir.
7. **Uzman çocuk ajanlar** (`ChildSpec`, roller) model düzeyinde tanımlı; kalıcı çocuk
   kimliği/izin kısıtı ve `createTaskAgent` bağlayıcısı E5'te tamamlanır. Arena
   `RED_TEAM` yalnızca veri külliyatıdır, ayrı bir ajan değildir.

## 7. Dosya düzeni

```
files/evolution/
  config.json            # ayarlar (preview/apply/rollback)
  constitution.json      # şeffaflık kopyası (hash doğrulanır)
  state.json             # aşama, güvenli mod
  journal/{turns,tools,trace,events}.jsonl
  gaps.jsonl             # kanıtlı eksikler (FALSE_POSITIVE dahil)
  genomes/               # genom dosyaları
  active_genome.json     # aktif genom işaretçisi
  generations.jsonl      # kuşaklar (silinmez)
  active_generation.json # aktif kuşak işaretçisi
  evals/catalog.json     # 30 görünür senaryo
  evals/heldout.index.json # 20 mühürlü id + hash (gövde yok)
  evals/results.jsonl
  arena/{corpus,results}
  resource/ledger.jsonl
  recipes.jsonl
  programs/              # L1 python programları (sürüm + rollback)
  prompts/               # L0 prompt pack'leri
  patches/               # planlar + pre-mortem
  artifacts/             # .next APK + build-info
  reports/               # diagnose/resource/dashboard
  secrets/github_token   # insan tarafından yazılır
  plugin_keys.json       # insan sahipliğinde yayıncı HMAC anahtarları
```

## 8. İlk kullanım

1. **Araçları aç.** Ayarlar → Araçlar bölümünde `self_*` araçları görünür. Hepsi
   varsayılan açıktır; yazma araçları guard'lıdır (`fs_edit` dry-run, commit yalnız
   aday dal, `install_artifact` yalnız `.next`). İstenirse tek tek kapatılabilir.
2. **GitHub'ı bağla.** `evolution_settings` aracını açtıktan sonra
   `evolution_settings(action="set_github_token", token="github_pat_…")`; ardından
   `github_status` ile bağlantıyı doğrula.
3. **Gözü aç.** `repo_sync` (ilk seferde ~20 MB) → `self_diagnose(days=7)` →
   `evolution_status`.
4. **Bir eksik seç.** `lineage`/`self_model` ile bağlamı gör; `patch_plan` ile planı
   kur. Onaylanan planı `fs_edit(dry_run=true)` ile denetle, sonra aday dala commit et.
5. **Rahmi çalıştır.** `compile_check(action="dispatch", branch="selfdev/…")` →
   `compile_check(action="status", run_id=…, wait_seconds=300)`.
6. **Kuşağı kaydet ve panoyu yayınla.** `gen_record`, `evolution_dashboard`.
   Terfi `promote.yml` + production onayıdır.
7. **Kendini sına.** `arena_run`, `evals_run`, `drift_check`, `resource_report`.
   `self-dev` becerisi ilk açılışta assets'ten kopyalanır ve disiplini taşır.

## 9. Ölçülen temel

Bu tasarım "daha iyi bir sürüm" değil, **kendi gelişimini yöneten** bir sistemdir:
kendi durumunu ölçer (jurnal), kendi sınavını tanımlar (eval + arena), kendi
değişikliğini denetler (pre-mortem + CRITIC + kapılar), kendi neslini kaydeder
(genom + soy ağacı) ve sınırını bilir (anayasa + vicdan + güvenli mod). Fenomenal
bilinç iddiası yoktur; ölçülebilir, denetlenebilir işlevsel farkındalık vardır.
