# İzin haritası (manifest ↔ özellik) — v1.22

S12: manifest'teki her izin bir özelliğe bağlı olmalı; kullanılmayan izin taşınmaz.
Bu sürümde **yeni izin eklenmedi**. Kurulum izni (`REQUEST_INSTALL_PACKAGES`) hâlâ
bilinçli olarak yok; `.next` APK kullanıcı onayına bırakılır.

| İzin | Kullanan | Not |
|---|---|---|
| `INTERNET` | LLM, GitHub, MCP, HTMLApps | normal |
| `ACCESS_NETWORK_STATE` | ağ/çevrimdışı kararları | normal |
| `SYSTEM_ALERT_WINDOW` | yüzen top / ekran kontrolü | kullanıcı ayarı; yoksa özellik kapalı |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE` | ajan turu, gece nöbeti | bildirimli |
| `POST_NOTIFICATIONS` | tur bildirimi, gece raporu | Android 13+ kullanıcı onayı |
| `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE` | dosya ekleri, dışa aktarma | eski Android; 33+ kısıtlı |
| `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_VISUAL_USER_SELECTED` | görsel/ekran görüntüsü | 33+ |
| `MANAGE_EXTERNAL_STORAGE` | tüm dosya erişimi (kullanıcı açarsa) | özel ayar sayfası; varsayılan kapalı |
| `CAMERA` | kamera karesi / vision | izin yoksa vision devre dışı |
| `RECORD_AUDIO` | sürekli sesli sohbet | izin yoksa sesli sohbet kapalı |
| `WAKE_LOCK` | uzun tur / gece nöbeti | süreli |
| `RECEIVE_BOOT_COMPLETED` | açılışta resident bildirim/planlama | boot alıcısı mevcut |

## Araçların izinle ilişkisi

- `shell`, `execute_python`, `fs_edit`, `repo_sync`: **yeni izin istemez**; uygulama
  sandbox'ı + kullanıcı onayı ile çalışır.
- `screen_operation`, `screenshot`, `screens`: erişilebilirlik/overlay izinlerine bağlı.
- `notify`: `POST_NOTIFICATIONS`.
- `install_artifact`: yalnız `.next` dosyası üretir; kurulum sistem onay ekranı.
- `night_shift`: pil/şarj/ekran koşulları; yeni izin yok (WorkManager).

## Denetim

- `docs/PERMISSIONS.md` ile manifest arasında fark varsa CI'da gözden geçirilmeli.
- Kullanılmayan bir izin kaldırılacaksa önce ilgili özelliğin kodda kullanılmadığı
  doğrulanmalı; bu tablo insan onayıyla güncellenir.
