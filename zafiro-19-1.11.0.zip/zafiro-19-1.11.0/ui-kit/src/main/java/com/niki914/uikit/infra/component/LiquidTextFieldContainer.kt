package com.niki914.uikit.infra.component

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.niki914.uikit.base.LocalAppDarkTheme
import com.niki914.uikit.infra.LiquidGlassPresets
import com.niki914.uikit.infra.LiquidGlassStyle
import com.niki914.uikit.infra.interaction.InteractiveHighlight
import com.niki914.uikit.infra.interaction.LiquidInteractiveStyle
import com.niki914.uikit.infra.interaction.applyLiquidInteractiveTransform
import com.niki914.uikit.infra.shape.G2FieldShape

private val LiquidTextFieldInteractiveStyle =
    LiquidInteractiveStyle(
        pressScalePx = 3.dp,
        maxDragScalePx = 3.dp,
    )

@Composable
internal fun LiquidTextFieldContainer(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    moveCursorToEndOnFocus: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    minHeight: Dp = 52.dp,
    contentVerticalAlignment: Alignment.Vertical = if (singleLine) Alignment.CenterVertically else Alignment.Top,
    onTextLayout: ((TextLayoutResult?) -> Unit)? = null,
    backdrop: Backdrop? = null,
    glassStyle: LiquidGlassStyle = LiquidGlassPresets.TextField,
    leadingContent: (@Composable RowScope.() -> Unit)? = null,
    trailingContent: (@Composable RowScope.() -> Unit)? = null,
) {
    val fallbackBackdrop = rememberLayerBackdrop()
    val resolvedBackdrop = backdrop ?: fallbackBackdrop
    val isDarkTheme = LocalAppDarkTheme.current
    val animationScope = rememberCoroutineScope()
    var isFocused by remember { mutableStateOf(false) }
    val interactiveHighlight = remember(animationScope) {
        InteractiveHighlight(animationScope = animationScope)
    }
    var textFieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = value,
                selection = TextRange(value.length),
            ),
        )
    }
    val interactiveEffectsEnabled = enabled && (!isFocused || textFieldValue.text.isEmpty())
    val fieldShape = G2FieldShape(36.dp)

    LaunchedEffect(value) {
        if (value != textFieldValue.text) {
            textFieldValue = textFieldValue.copy(
                text = value,
                selection = TextRange(value.length),
            )
        }
    }

    val colorScheme = MaterialTheme.colorScheme
    val textColor = if (enabled) {
        colorScheme.onSurface
    } else {
        colorScheme.onSurface.copy(alpha = 0.45f)
    }
    val placeholderColor = if (enabled) {
        colorScheme.onSurfaceVariant.copy(alpha = 0.72f)
    } else {
        colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
    }
    val trailingColor = if (enabled) {
        colorScheme.onSurfaceVariant
    } else {
        colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
    }
    val surfaceColor = if (enabled) {
        glassStyle.surfaceColor(isDarkTheme, colorScheme)
    } else {
        colorScheme.surfaceContainer.copy(alpha = 0.42f)
    }
    val tintColor = if (enabled) {
        colorScheme.primaryContainer.copy(alpha = 0.32f)
    } else {
        Color.Transparent
    }

    BasicTextField(
        value = textFieldValue,
        onValueChange = { nextValue ->
            textFieldValue = nextValue
            if (nextValue.text != value) {
                onValueChange(nextValue.text)
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = minHeight)
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
                if (moveCursorToEndOnFocus && focusState.isFocused) {
                    val textEnd = textFieldValue.text.length
                    if (textFieldValue.selection.start != textEnd ||
                        textFieldValue.selection.end != textEnd
                    ) {
                        textFieldValue = textFieldValue.copy(
                            selection = TextRange(textEnd),
                        )
                    }
                }
            }
            .drawBackdrop(
                backdrop = resolvedBackdrop,
                shape = { fieldShape },
                highlight = { glassStyle.highlight(isDarkTheme) },
                shadow = { glassStyle.shadow(isDarkTheme) },
                effects = {
                    glassStyle.applyEffects(this, isDarkTheme)
                },
                layerBlock = if (interactiveEffectsEnabled) {
                    {
                        applyLiquidInteractiveTransform(
                            style = LiquidTextFieldInteractiveStyle,
                            pressProgress = interactiveHighlight.pressProgress,
                            offset = interactiveHighlight.offset,
                            size = size,
                        )
                    }
                } else {
                    null
                },
                onDrawSurface = {
                    if (enabled) {
                        drawRect(tintColor, blendMode = BlendMode.Hue)
                    }
                    drawRect(surfaceColor)
                },
            )
            .clip(fieldShape)
            .then(
                if (interactiveEffectsEnabled && LiquidTextFieldInteractiveStyle.highlightEnabled) {
                    interactiveHighlight.modifier
                } else {
                    Modifier
                },
            )
            .then(if (interactiveEffectsEnabled) interactiveHighlight.gestureModifier else Modifier)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        enabled = enabled,
        singleLine = singleLine,
        minLines = minLines,
        maxLines = maxLines,
        visualTransformation = visualTransformation,
        textStyle = MaterialTheme.typography.bodyLarge.merge(
            TextStyle(color = textColor),
        ),
        cursorBrush = SolidColor(colorScheme.primary),
        onTextLayout = { layout -> onTextLayout?.invoke(layout) },
        decorationBox = { innerTextField ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = contentVerticalAlignment,
            ) {
                if (leadingContent != null) {
                    CompositionLocalProvider(LocalContentColor provides trailingColor) {
                        leadingContent(this@Row)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .widthIn(min = 0.dp),
                    contentAlignment = if (singleLine) Alignment.CenterStart else Alignment.TopStart,
                ) {
                    if (textFieldValue.text.isEmpty() && placeholder != null) {
                        Text(
                            text = placeholder,
                            style = MaterialTheme.typography.bodyLarge,
                            color = placeholderColor,
                            maxLines = if (singleLine) 1 else Int.MAX_VALUE,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    innerTextField()
                }

                if (trailingContent != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    CompositionLocalProvider(LocalContentColor provides trailingColor) {
                        trailingContent(this@Row)
                    }
                }
            }
        },
    )
}
